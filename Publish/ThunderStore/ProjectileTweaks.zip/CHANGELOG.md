<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.1.1</td>
			<td align="left">
				<ul>
					<li>Fixed README</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<b>Features</b>
					<li>Added a zoom feature when using bows and crossbows. (works with CameraTweaks changing the FoV.</li>
					<li>Added option to modify bow draw speed.</li>
					<li>Added option to modify crossbow reload speed.</li>
					<b>Backend</b>
					<li>Performance optimizations.</li>
					<li>Configuration changes immediately save to disk when in-game configuration manager is closed.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.3</td>
			<td align="left">
				<ul>
					<li>Updated manifest website link</li>
					<li>New icon</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.1/1.0.2</td>
			<td align="left">
				<ul>
					<li>Update for current game patch.</li>
					<li>Adds configuration option for spears.</li>
					<li>Fix README</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
